package org.greencodeinitiative.creedengo.java;

import java.util.Collections;
import java.util.List;

import org.greencodeinitiative.creedengo.java.checks.*;
import org.sonar.plugins.java.api.CheckRegistrar;
import org.sonar.plugins.java.api.JavaCheck;
import org.sonarsource.api.sonarlint.SonarLintSide;

@SonarLintSide
public class JavaCheckRegistrar implements CheckRegistrar {
    static final List<Class<? extends JavaCheck>> ANNOTATED_RULE_CLASSES = List.of(
            ArrayCopyCheck.class,
            IncrementCheck.class,
            AvoidUsageOfStaticCollections.class,
            AvoidGettingSizeCollectionInLoop.class,
            AvoidFullSQLRequest.class
    );

    /**
     * Register the classes that will be used to instantiate checks during analysis.
     */
    @Override
    public void register(RegistrarContext registrarContext) {
        // Call to registerClassesForRepository to associate the classes with the correct repository key
        registrarContext.registerClassesForRepository(
            JavaRulesDefinition.REPOSITORY_KEY, 
            checkClasses(), 
            testCheckClasses()
        );
    }

    /**
     * Lists all the main checks provided by the plugin
     */
    public static List<Class<? extends JavaCheck>> checkClasses() {
        return ANNOTATED_RULE_CLASSES;
    }

    /**
     * Lists all the test checks provided by the plugin
     */
    public static List<Class<? extends JavaCheck>> testCheckClasses() {
        return Collections.emptyList();
    }
}
